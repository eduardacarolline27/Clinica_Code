import tkinter as tk
from tkinter import ttk, messagebox
from tkcalendar import DateEntry
import db_manager
from datetime import datetime

class TelaConsultas:
    def __init__(self, container, conn):
        self.container = container
        self.conn = conn
        self.frame = ttk.Frame(self.container)

        self.medicos_map = {}
        self.pacientes_map = {}

        form_frame = ttk.LabelFrame(self.frame, text="Agendar/Editar Consulta")
        form_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        ttk.Label(form_frame, text="Médico:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.medico_combobox = ttk.Combobox(form_frame, state="readonly", width=38)
        self.medico_combobox.grid(row=0, column=1, columnspan=3, padx=5, pady=5, sticky="ew")
        self.carregar_medicos_combobox()

        ttk.Label(form_frame, text="Paciente:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.paciente_combobox = ttk.Combobox(form_frame, state="readonly", width=38)
        self.paciente_combobox.grid(row=1, column=1, columnspan=3, padx=5, pady=5, sticky="ew")
        self.carregar_pacientes_combobox()

        # Substituição de campo de data/hora por DateEntry + campo de hora
        ttk.Label(form_frame, text="Data:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.data_entry = DateEntry(form_frame, width=12, background='darkblue', foreground='white', date_pattern='yyyy-mm-dd')
        self.data_entry.grid(row=2, column=1, padx=5, pady=5, sticky="w")

        ttk.Label(form_frame, text="Hora (HH:MM):").grid(row=2, column=2, padx=5, pady=5, sticky="w")
        self.hora_entry = ttk.Entry(form_frame, width=10)
        self.hora_entry.grid(row=2, column=3, padx=5, pady=5, sticky="w")

        ttk.Label(form_frame, text="Observações:").grid(row=3, column=0, padx=5, pady=5, sticky="nw")
        self.obs_text = tk.Text(form_frame, width=40, height=4)
        self.obs_text.grid(row=3, column=1, columnspan=3, padx=5, pady=5, sticky="ew")

        button_frame = ttk.Frame(self.frame)
        button_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew")

        self.add_button = ttk.Button(button_frame, text="Agendar", command=self.agendar_consulta)
        self.add_button.pack(side=tk.LEFT, padx=5)

        self.update_button = ttk.Button(button_frame, text="Atualizar", command=self.atualizar_consulta)
        self.update_button.pack(side=tk.LEFT, padx=5)

        self.delete_button = ttk.Button(button_frame, text="Deletar", command=self.deletar_consulta)
        self.delete_button.pack(side=tk.LEFT, padx=5)

        self.clear_button = ttk.Button(button_frame, text="Limpar Campos", command=self.limpar_campos)
        self.clear_button.pack(side=tk.LEFT, padx=5)

        tree_frame = ttk.Frame(self.frame)
        tree_frame.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")

        self.tree = ttk.Treeview(tree_frame, columns=("ID", "Data/Hora", "Médico", "Paciente", "Obs"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Data/Hora", text="Data/Hora")
        self.tree.heading("Médico", text="Médico")
        self.tree.heading("Paciente", text="Paciente")
        self.tree.heading("Obs", text="Observações")

        self.tree.column("ID", width=50, anchor=tk.CENTER)
        self.tree.column("Data/Hora", width=120, anchor=tk.CENTER)
        self.tree.column("Médico", width=200)
        self.tree.column("Paciente", width=200)
        self.tree.column("Obs", width=200)

        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        self.frame.grid_rowconfigure(2, weight=1)
        self.frame.grid_columnconfigure(0, weight=1)
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        self.tree.bind("<<TreeviewSelect>>", self.item_selecionado)

        self.carregar_consultas()
        self.frame.pack(fill=tk.BOTH, expand=True)

    def carregar_medicos_combobox(self):
        medicos = db_manager.listar_medicos(self.conn)
        medico_nomes = []
        self.medicos_map.clear()
        for medico in medicos:
            nome_display = f"{medico['nome']} ({medico['especialidade']})" if medico['especialidade'] else medico['nome']
            self.medicos_map[nome_display] = medico['id_medico']
            medico_nomes.append(nome_display)
        self.medico_combobox['values'] = medico_nomes

    def carregar_pacientes_combobox(self):
        pacientes = db_manager.listar_pacientes(self.conn)
        paciente_nomes = []
        self.pacientes_map.clear()
        for paciente in pacientes:
            self.pacientes_map[paciente['nome']] = paciente['id_paciente']
            paciente_nomes.append(paciente['nome'])
        self.paciente_combobox['values'] = paciente_nomes

    def carregar_consultas(self):
        for i in self.tree.get_children():
            self.tree.delete(i)
        consultas = db_manager.listar_consultas(self.conn)
        for consulta in consultas:
            self.tree.insert("", tk.END, values=(
                consulta["id_consulta"],
                consulta["data_hora"],
                consulta["nome_medico"],
                consulta["nome_paciente"],
                consulta["observacoes"]
            ))

    def validar_data_hora(self, data_hora_str):
        try:
            datetime.strptime(data_hora_str, '%Y-%m-%d %H:%M')
            return True
        except ValueError:
            messagebox.showerror("Erro de Formato", "Formato de Data/Hora inválido. Use AAAA-MM-DD HH:MM.")
            return False

    def agendar_consulta(self):
        medico_selecionado = self.medico_combobox.get()
        paciente_selecionado = self.paciente_combobox.get()
        data = self.data_entry.get()
        hora = self.hora_entry.get()
        data_hora = f"{data} {hora}"
        observacoes = self.obs_text.get("1.0", tk.END).strip()

        if not medico_selecionado or not paciente_selecionado or not data or not hora:
            messagebox.showerror("Erro", "Médico, Paciente, Data e Hora são obrigatórios.")
            return

        if not self.validar_data_hora(data_hora):
            return

        id_medico = self.medicos_map.get(medico_selecionado)
        id_paciente = self.pacientes_map.get(paciente_selecionado)

        if not id_medico or not id_paciente:
            messagebox.showerror("Erro", "Médico ou Paciente inválido selecionado.")
            return

        if db_manager.adicionar_consulta(self.conn, id_medico, id_paciente, data_hora, observacoes):
            messagebox.showinfo("Sucesso", "Consulta agendada com sucesso!")
            self.limpar_campos()
            self.carregar_consultas()
            self.carregar_medicos_combobox()
            self.carregar_pacientes_combobox()
        else:
            messagebox.showerror("Erro", "Falha ao agendar consulta.")

    def atualizar_consulta(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Erro", "Selecione uma consulta para atualizar.")
            return

        item = selected_item[0]
        id_consulta = self.tree.item(item, "values")[0]

        medico_selecionado = self.medico_combobox.get()
        paciente_selecionado = self.paciente_combobox.get()
        data = self.data_entry.get()
        hora = self.hora_entry.get()
        data_hora = f"{data} {hora}"
        observacoes = self.obs_text.get("1.0", tk.END).strip()

        if not medico_selecionado or not paciente_selecionado or not data or not hora:
            messagebox.showerror("Erro", "Médico, Paciente, Data e Hora são obrigatórios.")
            return

        if not self.validar_data_hora(data_hora):
            return

        id_medico = self.medicos_map.get(medico_selecionado)
        id_paciente = self.pacientes_map.get(paciente_selecionado)

        if not id_medico or not id_paciente:
            messagebox.showerror("Erro", "Médico ou Paciente inválido selecionado.")
            return

        if db_manager.atualizar_consulta(self.conn, id_consulta, id_medico, id_paciente, data_hora, observacoes):
            messagebox.showinfo("Sucesso", "Consulta atualizada com sucesso!")
            self.limpar_campos()
            self.carregar_consultas()
            self.carregar_medicos_combobox()
            self.carregar_pacientes_combobox()
        else:
            messagebox.showerror("Erro", "Falha ao atualizar consulta.")

    def deletar_consulta(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Erro", "Selecione uma consulta para deletar.")
            return

        item = selected_item[0]
        id_consulta = self.tree.item(item, "values")[0]
        data_hora_consulta = self.tree.item(item, "values")[1]

        confirm = messagebox.askyesno("Confirmar Deleção", f"Tem certeza que deseja deletar a consulta do dia {data_hora_consulta}?")
        if confirm:
            if db_manager.deletar_consulta(self.conn, id_consulta):
                messagebox.showinfo("Sucesso", "Consulta deletada com sucesso!")
                self.limpar_campos()
                self.carregar_consultas()
            else:
                messagebox.showerror("Erro", "Falha ao deletar consulta.")

    def limpar_campos(self):
        self.medico_combobox.set('')
        self.paciente_combobox.set('')
        self.data_entry.set_date(datetime.today())
        self.hora_entry.delete(0, tk.END)
        self.obs_text.delete("1.0", tk.END)
        self.tree.selection_remove(self.tree.selection())

    def item_selecionado(self, event):
        selected_item = self.tree.selection()
        if not selected_item:
            return

        item = selected_item[0]
        values = self.tree.item(item, "values")

        consulta_detalhes = None
        consultas_raw = db_manager.listar_consultas(self.conn)
        for c in consultas_raw:
            if c['id_consulta'] == int(values[0]):
                consulta_detalhes = c
                break

        if not consulta_detalhes:
            print("Erro: Não foi possível encontrar detalhes da consulta selecionada.")
            self.limpar_campos()
            return

        medico_key = next((key for key, val in self.medicos_map.items() if val == consulta_detalhes['id_medico']), '')
        paciente_key = next((key for key, val in self.pacientes_map.items() if val == consulta_detalhes['id_paciente']), '')

        self.medico_combobox.set(medico_key)
        self.paciente_combobox.set(paciente_key)

        try:
            data_hora = datetime.strptime(values[1], "%Y-%m-%d %H:%M")
            self.data_entry.set_date(data_hora.date())
            self.hora_entry.delete(0, tk.END)
            self.hora_entry.insert(0, data_hora.strftime("%H:%M"))
        except:
            self.data_entry.set_date(datetime.today())
            self.hora_entry.delete(0, tk.END)

        self.obs_text.delete("1.0", tk.END)
        self.obs_text.insert("1.0", values[4])

def abrir_tela_consultas(container, conn):
    for widget in container.winfo_children():
        widget.destroy()
    TelaConsultas(container, conn)