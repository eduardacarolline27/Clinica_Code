import tkinter as tk
from tkinter import ttk, messagebox
import db_manager

class TelaMedicos:
    def __init__(self, container, conn):
        self.container = container
        self.conn = conn
        self.frame = ttk.Frame(self.container)

        # --- Widgets --- #
        # Frame para o formulário
        form_frame = ttk.LabelFrame(self.frame, text="Dados do Médico")
        form_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        ttk.Label(form_frame, text="Nome:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nome_entry = ttk.Entry(form_frame, width=40)
        self.nome_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(form_frame, text="Especialidade:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.especialidade_entry = ttk.Entry(form_frame, width=40)
        self.especialidade_entry.grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        # Frame para os botões
        button_frame = ttk.Frame(self.frame)
        button_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew")

        self.add_button = ttk.Button(button_frame, text="Adicionar", command=self.adicionar_medico)
        self.add_button.pack(side=tk.LEFT, padx=5)

        self.update_button = ttk.Button(button_frame, text="Atualizar", command=self.atualizar_medico)
        self.update_button.pack(side=tk.LEFT, padx=5)

        self.delete_button = ttk.Button(button_frame, text="Deletar", command=self.deletar_medico)
        self.delete_button.pack(side=tk.LEFT, padx=5)

        self.clear_button = ttk.Button(button_frame, text="Limpar Campos", command=self.limpar_campos)
        self.clear_button.pack(side=tk.LEFT, padx=5)

        # Frame para a Treeview
        tree_frame = ttk.Frame(self.frame)
        tree_frame.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")

        # Configurar colunas da Treeview
        self.tree = ttk.Treeview(tree_frame, columns=("ID", "Nome", "Especialidade"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Especialidade", text="Especialidade")

        # Ajustar largura das colunas
        self.tree.column("ID", width=50, anchor=tk.CENTER)
        self.tree.column("Nome", width=300)
        self.tree.column("Especialidade", width=200)

        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        # Configurar expansão da Treeview
        self.frame.grid_rowconfigure(2, weight=1)
        self.frame.grid_columnconfigure(0, weight=1)
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        # Vincular evento de seleção
        self.tree.bind("<<TreeviewSelect>>", self.item_selecionado)

        # Carregar dados iniciais
        self.carregar_medicos()

        # Adicionar o frame principal ao container
        self.frame.pack(fill=tk.BOTH, expand=True)

    def carregar_medicos(self):
        # Limpar Treeview
        for i in self.tree.get_children():
            self.tree.delete(i)
        # Buscar dados no BD
        medicos = db_manager.listar_medicos(self.conn)
        for medico in medicos:
            self.tree.insert("", tk.END, values=(medico["id_medico"], medico["nome"], medico["especialidade"]))

    def adicionar_medico(self):
        nome = self.nome_entry.get()
        especialidade = self.especialidade_entry.get()

        if not nome:
            messagebox.showerror("Erro", "O nome do médico é obrigatório.")
            return

        if db_manager.adicionar_medico(self.conn, nome, especialidade):
            messagebox.showinfo("Sucesso", "Médico adicionado com sucesso!")
            self.limpar_campos()
            self.carregar_medicos()
        else:
            messagebox.showerror("Erro", "Falha ao adicionar médico.")

    def atualizar_medico(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Erro", "Selecione um médico para atualizar.")
            return

        item = selected_item[0]
        id_medico = self.tree.item(item, "values")[0]
        nome = self.nome_entry.get()
        especialidade = self.especialidade_entry.get()

        if not nome:
            messagebox.showerror("Erro", "O nome do médico é obrigatório.")
            return

        if db_manager.atualizar_medico(self.conn, id_medico, nome, especialidade):
            messagebox.showinfo("Sucesso", "Médico atualizado com sucesso!")
            self.limpar_campos()
            self.carregar_medicos()
        else:
            messagebox.showerror("Erro", "Falha ao atualizar médico.")

    def deletar_medico(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Erro", "Selecione um médico para deletar.")
            return

        item = selected_item[0]
        id_medico = self.tree.item(item, "values")[0]
        nome_medico = self.tree.item(item, "values")[1]

        confirm = messagebox.askyesno("Confirmar Deleção", f"Tem certeza que deseja deletar o médico \"{nome_medico}\"? Isso também deletará todas as consultas associadas a ele.")
        if confirm:
            if db_manager.deletar_medico(self.conn, id_medico):
                messagebox.showinfo("Sucesso", "Médico deletado com sucesso!")
                self.limpar_campos()
                self.carregar_medicos()
            else:
                messagebox.showerror("Erro", "Falha ao deletar médico.")

    def limpar_campos(self):
        self.nome_entry.delete(0, tk.END)
        self.especialidade_entry.delete(0, tk.END)
        self.tree.selection_remove(self.tree.selection()) # Desseleciona item na treeview

    def item_selecionado(self, event):
        selected_item = self.tree.selection()
        if not selected_item:
            return

        item = selected_item[0]
        values = self.tree.item(item, "values")

        self.nome_entry.delete(0, tk.END)
        self.nome_entry.insert(0, values[1])

        self.especialidade_entry.delete(0, tk.END)
        self.especialidade_entry.insert(0, values[2])

# Função para ser chamada pelo main.py
def abrir_tela_medicos(container, conn):
    # Limpa o container antes de adicionar a nova tela
    for widget in container.winfo_children():
        widget.destroy()
    # Cria a instância da tela
    TelaMedicos(container, conn)