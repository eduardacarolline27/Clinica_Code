import sqlite3
import os

DB_FILE = "agenda_medica.db"

def conectar_bd():
    """Conecta ao banco de dados SQLite."""
    try:
        conn = sqlite3.connect(DB_FILE)
        conn.row_factory = sqlite3.Row # Retorna linhas como dicionários
        conn.execute("PRAGMA foreign_keys = ON") # Habilita chaves estrangeiras
        return conn
    except sqlite3.Error as e:
        print(f"Erro ao conectar ao banco de dados: {e}")
        return None

def criar_tabelas(conn):
    """Cria as tabelas no banco de dados se não existirem."""
    cursor = conn.cursor()
    try:
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS medico (
            id_medico INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            especialidade TEXT
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS paciente (
            id_paciente INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT NOT NULL,
            data_nascimento TEXT,
            telefone TEXT
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS consulta (
            id_consulta INTEGER PRIMARY KEY AUTOINCREMENT,
            id_medico INTEGER NOT NULL,
            id_paciente INTEGER NOT NULL,
            data_hora TEXT NOT NULL, -- Formato recomendado: YYYY-MM-DD HH:MM
            observacoes TEXT,
            FOREIGN KEY (id_medico) REFERENCES medico (id_medico) ON DELETE CASCADE,
            FOREIGN KEY (id_paciente) REFERENCES paciente (id_paciente) ON DELETE CASCADE
        );
        """)
        conn.commit()
        print("Tabelas criadas com sucesso (se não existiam).")
    except sqlite3.Error as e:
        print(f"Erro ao criar tabelas: {e}")
    finally:
        cursor.close()

def inicializar_bd():
    """Inicializa o banco de dados: conecta e cria as tabelas."""
    # Verifica se o arquivo do banco de dados existe e tem tamanho maior que 0
    # Uma verificação mais robusta poderia checar a existência das tabelas
    db_existe = os.path.exists(DB_FILE) and os.path.getsize(DB_FILE) > 0

    conn = conectar_bd()
    if conn:
        if not db_existe:
            print("Banco de dados não encontrado ou vazio. Criando tabelas...")
            criar_tabelas(conn)
        else:
            print("Banco de dados encontrado.")
        # Não fechamos a conexão aqui, pois ela pode ser usada por outras partes
        # A responsabilidade de fechar a conexão será de quem a utiliza.
        # conn.close() # Removido - a conexão será gerenciada externamente
        return conn # Retorna a conexão para uso
    return None

# --- Funções CRUD para Médicos ---

def adicionar_medico(conn, nome, especialidade):
    sql = 'INSERT INTO medico(nome, especialidade) VALUES(?,?)'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (nome, especialidade))
        conn.commit()
        print(f"Médico '{nome}' adicionado com sucesso.")
        return cursor.lastrowid
    except sqlite3.Error as e:
        print(f"Erro ao adicionar médico: {e}")
        conn.rollback()
        return None
    finally:
        cursor.close()

def listar_medicos(conn):
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM medico ORDER BY nome")
        return cursor.fetchall()
    except sqlite3.Error as e:
        print(f"Erro ao listar médicos: {e}")
        return []
    finally:
        cursor.close()

def atualizar_medico(conn, id_medico, nome, especialidade):
    sql = 'UPDATE medico SET nome = ?, especialidade = ? WHERE id_medico = ?'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (nome, especialidade, id_medico))
        conn.commit()
        print(f"Médico ID {id_medico} atualizado com sucesso.")
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(f"Erro ao atualizar médico: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()

def deletar_medico(conn, id_medico):
    sql = 'DELETE FROM medico WHERE id_medico = ?'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (id_medico,))
        conn.commit()
        print(f"Médico ID {id_medico} deletado com sucesso.")
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(f"Erro ao deletar médico: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()

# --- Funções CRUD para Pacientes ---

def adicionar_paciente(conn, nome, data_nascimento, telefone):
    sql = 'INSERT INTO paciente(nome, data_nascimento, telefone) VALUES(?,?,?)'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (nome, data_nascimento, telefone))
        conn.commit()
        print(f"Paciente '{nome}' adicionado com sucesso.")
        return cursor.lastrowid
    except sqlite3.Error as e:
        print(f"Erro ao adicionar paciente: {e}")
        conn.rollback()
        return None
    finally:
        cursor.close()

def listar_pacientes(conn):
    cursor = conn.cursor()
    try:
        cursor.execute("SELECT * FROM paciente ORDER BY nome")
        return cursor.fetchall()
    except sqlite3.Error as e:
        print(f"Erro ao listar pacientes: {e}")
        return []
    finally:
        cursor.close()

def atualizar_paciente(conn, id_paciente, nome, data_nascimento, telefone):
    sql = 'UPDATE paciente SET nome = ?, data_nascimento = ?, telefone = ? WHERE id_paciente = ?'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (nome, data_nascimento, telefone, id_paciente))
        conn.commit()
        print(f"Paciente ID {id_paciente} atualizado com sucesso.")
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(f"Erro ao atualizar paciente: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()

def deletar_paciente(conn, id_paciente):
    sql = 'DELETE FROM paciente WHERE id_paciente = ?'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (id_paciente,))
        conn.commit()
        print(f"Paciente ID {id_paciente} deletado com sucesso.")
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(f"Erro ao deletar paciente: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()

# --- Funções CRUD para Consultas ---

def adicionar_consulta(conn, id_medico, id_paciente, data_hora, observacoes):
    sql = 'INSERT INTO consulta(id_medico, id_paciente, data_hora, observacoes) VALUES(?,?,?,?)'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (id_medico, id_paciente, data_hora, observacoes))
        conn.commit()
        print(f"Consulta agendada para {data_hora} com sucesso.")
        return cursor.lastrowid
    except sqlite3.Error as e:
        print(f"Erro ao agendar consulta: {e}")
        conn.rollback()
        return None
    finally:
        cursor.close()

def listar_consultas(conn):
    """Lista todas as consultas com nomes de médico e paciente."""
    sql = """
    SELECT
        c.id_consulta,
        c.data_hora,
        m.nome AS nome_medico,
        p.nome AS nome_paciente,
        c.observacoes,
        c.id_medico,
        c.id_paciente
    FROM consulta c
    JOIN medico m ON c.id_medico = m.id_medico
    JOIN paciente p ON c.id_paciente = p.id_paciente
    ORDER BY c.data_hora
    """
    cursor = conn.cursor()
    try:
        cursor.execute(sql)
        return cursor.fetchall()
    except sqlite3.Error as e:
        print(f"Erro ao listar consultas: {e}")
        return []
    finally:
        cursor.close()

def atualizar_consulta(conn, id_consulta, id_medico, id_paciente, data_hora, observacoes):
    sql = 'UPDATE consulta SET id_medico = ?, id_paciente = ?, data_hora = ?, observacoes = ? WHERE id_consulta = ?'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (id_medico, id_paciente, data_hora, observacoes, id_consulta))
        conn.commit()
        print(f"Consulta ID {id_consulta} atualizada com sucesso.")
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(f"Erro ao atualizar consulta: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()

def deletar_consulta(conn, id_consulta):
    sql = 'DELETE FROM consulta WHERE id_consulta = ?'
    cursor = conn.cursor()
    try:
        cursor.execute(sql, (id_consulta,))
        conn.commit()
        print(f"Consulta ID {id_consulta} deletada com sucesso.")
        return cursor.rowcount > 0
    except sqlite3.Error as e:
        print(f"Erro ao deletar consulta: {e}")
        conn.rollback()
        return False
    finally:
        cursor.close()

# Exemplo de uso (para teste inicial)
if __name__ == "__main__":
    print("Inicializando o gerenciador de banco de dados...")
    conexao = inicializar_bd()
    if conexao:
        print("Banco de dados inicializado com sucesso.")
        # Teste rápido (opcional)
        # id_med = adicionar_medico(conexao, "Dr. House", "Diagnóstico")
        # id_pac = adicionar_paciente(conexao, "John Doe", "1980-01-01", "555-1234")
        # if id_med and id_pac:
        #     adicionar_consulta(conexao, id_med, id_pac, "2025-06-01 10:00", "Caso complexo")
        # print("\nMédicos:")
        # for medico in listar_medicos(conexao):
        #     print(dict(medico))
        # print("\nPacientes:")
        # for paciente in listar_pacientes(conexao):
        #     print(dict(paciente))
        # print("\nConsultas:")
        # for consulta in listar_consultas(conexao):
        #     print(dict(consulta))
        conexao.close()
        print("Conexão fechada.")
    else:
        print("Falha ao inicializar o banco de dados.")