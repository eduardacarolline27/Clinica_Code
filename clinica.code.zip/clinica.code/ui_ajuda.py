import tkinter as tk
from tkinter import messagebox

def mostrar_sobre():
    """Exibe a janela 'Sobre' com informações do projeto e integrantes."""
    integrantes = "Eduarda Carolline" # Nome fornecido pelo usuário
    titulo = "Agenda Médica"
    descricao = ("Aplicação para gerenciamento de médicos, pacientes e consultas.\n"
                 "Desenvolvida como parte do desafio de integração com interface gráfica e banco de dados.")

    messagebox.showinfo(
        f"Sobre - {titulo}",
        f"Título: {titulo}\n\n"
        f"Descrição: {descricao}\n\n"
        f"Integrantes: {integrantes}"
    )

# Este arquivo pode ser importado diretamente no main.py
# Exemplo de como chamar a função:
# import ui_ajuda
# ui_ajuda.mostrar_sobre()