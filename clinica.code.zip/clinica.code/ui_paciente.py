import tkinter as tk
from tkinter import ttk, messagebox
import db_manager

class TelaPacientes:
    def __init__(self, container, conn):
        self.container = container
        self.conn = conn
        self.frame = ttk.Frame(self.container)

        # --- Widgets --- #
        # Frame para o formulário
        form_frame = ttk.LabelFrame(self.frame, text="Dados do Paciente")
        form_frame.grid(row=0, column=0, padx=10, pady=10, sticky="ew")

        ttk.Label(form_frame, text="Nome:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        self.nome_entry = ttk.Entry(form_frame, width=40)
        self.nome_entry.grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ttk.Label(form_frame, text="Data Nasc.:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        self.data_nasc_entry = ttk.Entry(form_frame, width=20)
        self.data_nasc_entry.grid(row=1, column=1, padx=5, pady=5, sticky="w")
        ttk.Label(form_frame, text="(AAAA-MM-DD)").grid(row=1, column=2, padx=5, pady=5, sticky="w")

        ttk.Label(form_frame, text="Telefone:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        self.telefone_entry = ttk.Entry(form_frame, width=20)
        self.telefone_entry.grid(row=2, column=1, padx=5, pady=5, sticky="w")

        # Frame para os botões
        button_frame = ttk.Frame(self.frame)
        button_frame.grid(row=1, column=0, padx=10, pady=10, sticky="ew")

        self.add_button = ttk.Button(button_frame, text="Adicionar", command=self.adicionar_paciente)
        self.add_button.pack(side=tk.LEFT, padx=5)

        self.update_button = ttk.Button(button_frame, text="Atualizar", command=self.atualizar_paciente)
        self.update_button.pack(side=tk.LEFT, padx=5)

        self.delete_button = ttk.Button(button_frame, text="Deletar", command=self.deletar_paciente)
        self.delete_button.pack(side=tk.LEFT, padx=5)

        self.clear_button = ttk.Button(button_frame, text="Limpar Campos", command=self.limpar_campos)
        self.clear_button.pack(side=tk.LEFT, padx=5)

        # Frame para a Treeview
        tree_frame = ttk.Frame(self.frame)
        tree_frame.grid(row=2, column=0, padx=10, pady=10, sticky="nsew")

        # Configurar colunas da Treeview
        self.tree = ttk.Treeview(tree_frame, columns=("ID", "Nome", "Data Nasc.", "Telefone"), show="headings")
        self.tree.heading("ID", text="ID")
        self.tree.heading("Nome", text="Nome")
        self.tree.heading("Data Nasc.", text="Data Nasc.")
        self.tree.heading("Telefone", text="Telefone")

        # Ajustar largura das colunas
        self.tree.column("ID", width=50, anchor=tk.CENTER)
        self.tree.column("Nome", width=300)
        self.tree.column("Data Nasc.", width=100, anchor=tk.CENTER)
        self.tree.column("Telefone", width=150)

        # Scrollbar
        scrollbar = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=scrollbar.set)

        self.tree.grid(row=0, column=0, sticky="nsew")
        scrollbar.grid(row=0, column=1, sticky="ns")

        # Configurar expansão da Treeview
        self.frame.grid_rowconfigure(2, weight=1)
        self.frame.grid_columnconfigure(0, weight=1)
        tree_frame.grid_rowconfigure(0, weight=1)
        tree_frame.grid_columnconfigure(0, weight=1)

        # Vincular evento de seleção
        self.tree.bind("<<TreeviewSelect>>", self.item_selecionado)

        # Carregar dados iniciais
        self.carregar_pacientes()

        # Adicionar o frame principal ao container
        self.frame.pack(fill=tk.BOTH, expand=True)

    def carregar_pacientes(self):
        # Limpar Treeview
        for i in self.tree.get_children():
            self.tree.delete(i)
        # Buscar dados no BD
        pacientes = db_manager.listar_pacientes(self.conn)
        for paciente in pacientes:
            self.tree.insert("", tk.END, values=(paciente["id_paciente"], paciente["nome"], paciente["data_nascimento"], paciente["telefone"]))

    def adicionar_paciente(self):
        nome = self.nome_entry.get()
        data_nasc = self.data_nasc_entry.get()
        telefone = self.telefone_entry.get()

        if not nome:
            messagebox.showerror("Erro", "O nome do paciente é obrigatório.")
            return
        # TODO: Adicionar validação para formato da data

        if db_manager.adicionar_paciente(self.conn, nome, data_nasc, telefone):
            messagebox.showinfo("Sucesso", "Paciente adicionado com sucesso!")
            self.limpar_campos()
            self.carregar_pacientes()
        else:
            messagebox.showerror("Erro", "Falha ao adicionar paciente.")

    def atualizar_paciente(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Erro", "Selecione um paciente para atualizar.")
            return

        item = selected_item[0]
        id_paciente = self.tree.item(item, "values")[0]
        nome = self.nome_entry.get()
        data_nasc = self.data_nasc_entry.get()
        telefone = self.telefone_entry.get()

        if not nome:
            messagebox.showerror("Erro", "O nome do paciente é obrigatório.")
            return
        # TODO: Adicionar validação para formato da data

        if db_manager.atualizar_paciente(self.conn, id_paciente, nome, data_nasc, telefone):
            messagebox.showinfo("Sucesso", "Paciente atualizado com sucesso!")
            self.limpar_campos()
            self.carregar_pacientes()
        else:
            messagebox.showerror("Erro", "Falha ao atualizar paciente.")

    def deletar_paciente(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Erro", "Selecione um paciente para deletar.")
            return

        item = selected_item[0]
        id_paciente = self.tree.item(item, "values")[0]
        nome_paciente = self.tree.item(item, "values")[1]

        confirm = messagebox.askyesno("Confirmar Deleção", f"Tem certeza que deseja deletar o paciente \"{nome_paciente}\"? Isso também deletará todas as consultas associadas a ele.")
        if confirm:
            if db_manager.deletar_paciente(self.conn, id_paciente):
                messagebox.showinfo("Sucesso", "Paciente deletado com sucesso!")
                self.limpar_campos()
                self.carregar_pacientes()
            else:
                messagebox.showerror("Erro", "Falha ao deletar paciente.")

    def limpar_campos(self):
        self.nome_entry.delete(0, tk.END)
        self.data_nasc_entry.delete(0, tk.END)
        self.telefone_entry.delete(0, tk.END)
        self.tree.selection_remove(self.tree.selection()) # Desseleciona item na treeview

    def item_selecionado(self, event):
        selected_item = self.tree.selection()
        if not selected_item:
            return

        item = selected_item[0]
        values = self.tree.item(item, "values")

        self.nome_entry.delete(0, tk.END)
        self.nome_entry.insert(0, values[1])

        self.data_nasc_entry.delete(0, tk.END)
        self.data_nasc_entry.insert(0, values[2])

        self.telefone_entry.delete(0, tk.END)
        self.telefone_entry.insert(0, values[3])

# Função para ser chamada pelo main.py
def abrir_tela_pacientes(container, conn):
    # Limpa o container antes de adicionar a nova tela
    for widget in container.winfo_children():
        widget.destroy()
    # Cria a instância da tela
    TelaPacientes(container, conn)