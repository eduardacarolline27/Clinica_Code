import tkinter as tk
from tkinter import ttk, messagebox
import db_manager
# Importar os módulos das telas e da ajuda
import ui_medico
import ui_paciente
import ui_consulta
import ui_ajuda

class App(tk.Tk):
    def __init__(self, conn):
        super().__init__()
        self.conn = conn
        self.title("Agenda Médica")
        # Definir um tamanho mínimo e permitir redimensionamento
        self.minsize(800, 600)
        # Centralizar a janela (opcional, pode variar dependendo do SO/WM)
        # self.eval('tk::PlaceWindow . center')

        # Container principal para as telas
        # Usar pack com fill e expand para ocupar o espaço disponível
        self.container = ttk.Frame(self)
        self.container.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Cria a barra de menus
        self.criar_menu()

        # Exibe uma tela inicial
        self.mostrar_tela_inicial()

    def criar_menu(self):
        menubar = tk.Menu(self)
        self.config(menu=menubar)

        # Menu Cadastros
        menu_cadastros = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Cadastros", menu=menu_cadastros)
        # Usar as funções importadas dos módulos UI
        menu_cadastros.add_command(label="Médicos", command=lambda: ui_medico.abrir_tela_medicos(self.container, self.conn))
        menu_cadastros.add_command(label="Pacientes", command=lambda: ui_paciente.abrir_tela_pacientes(self.container, self.conn))

        # Menu Agendamento
        menu_agendamento = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Agendamento", menu=menu_agendamento)
        menu_agendamento.add_command(label="Consultas", command=lambda: ui_consulta.abrir_tela_consultas(self.container, self.conn))

        # Menu Ajuda
        menu_ajuda_menu = tk.Menu(menubar, tearoff=0) # Renomeado para evitar conflito
        menubar.add_cascade(label="Ajuda", menu=menu_ajuda_menu)
        # Usar a função importada do módulo ui_ajuda
        menu_ajuda_menu.add_command(label="Sobre", command=ui_ajuda.mostrar_sobre)

    def mostrar_tela_inicial(self):
        """Mostra uma mensagem de boas-vindas no container."""
        # Limpa o container antes de adicionar a nova tela
        for widget in self.container.winfo_children():
            widget.destroy()
        label = ttk.Label(self.container, text="Bem-vindo à Agenda Médica!\nUse o menu superior para navegar.", font=("Arial", 14), justify=tk.CENTER)
        # Usar pack com expand para centralizar melhor
        label.pack(padx=20, pady=50, expand=True)

if __name__ == "__main__":
    print("Iniciando aplicação Agenda Médica...")
    conexao = db_manager.inicializar_bd()
    if conexao:
        app = App(conexao)
        app.mainloop()
        # Fecha a conexão com o BD ao sair da aplicação
        conexao.close()
        print("Conexão com o banco de dados fechada.")
    else:
        print("Erro: Não foi possível conectar ao banco de dados. A aplicação não pode iniciar.")
        messagebox.showerror("Erro de Banco de Dados", "Não foi possível conectar ao banco de dados SQLite. Verifique o console para mais detalhes.")